# Gasite

Gasite is a zero-setup, installable web app (PWA) for finding nearby gas stations using OpenStreetMap (via Overpass API). No API keys required.

## Features
- Current location detection (with fallback to Riyadh if denied).
- Interactive map (OpenStreetMap + Leaflet).
- Distance-sorted list of stations with brand, basic hours, and fuel badges (Diesel, 95, 91, EV when tagged).
- Filters: 24/7, Diesel, Gasoline, Octane 95, Octane 91, EV charging.
- One-tap navigation (Apple Maps on iOS, Google Maps elsewhere).
- PWA: install on mobile/home screen; offline caching of the UI.
- Privacy: no analytics, no accounts.

## Deploy
1. Upload the folder contents to any static host (GitHub Pages, Netlify, Vercel, Cloudflare Pages, or your own server).
2. Ensure the site is served over HTTPS for geolocation to work.
3. Done. The app will prompt users to install it (Add to Home Screen).

## Local preview
- Use any static server. For example with Python:
  ```bash
  cd gasite
  python3 -m http.server 8080
  ```
  Then open http://localhost:8080

## Notes
- Data quality depends on OpenStreetMap coverage in your area.
- Overpass public endpoints have rate limits; if a search fails, try again later.
- Opening hours are shown as provided; real-time "open now" status is not computed.
- If you need proprietary POIs, plug in Google Places or TomTom APIs (requires keys).

## Customize
- Colors & UI: edit `styles.css`.
- Radius defaults: in `index.html` range input.
- Logic/filters: edit `main.js`.
- Icons: replace the PNGs under `icons/`.

## License
MIT — do anything, but no warranty.
