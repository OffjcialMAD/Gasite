/* Gasite — nearest gas stations (PWA) */
const $ = (sel, root=document) => root.querySelector(sel);
const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));

const state = {
  userPos: null,
  map: null,
  markers: L.markerClusterGroup ? L.markerClusterGroup() : null,
  layer: null,
  lastResults: [],
  isIOS: /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream
};

// Fallback list of Overpass endpoints (we'll try in order)
const OVERPASS = [
  "https://overpass-api.de/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter",
  "https://overpass.openstreetmap.ru/api/interpreter"
];

function km(m){return (m/1000).toFixed(1)}

function haversine(a, b){
  const toRad = d => d * Math.PI/180;
  const R = 6371000;
  const dLat = toRad(b.lat - a.lat);
  const dLon = toRad(b.lon - a.lon);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const s = Math.sin(dLat/2)**2 + Math.cos(lat1)*Math.cos(lat2)*Math.sin(dLon/2)**2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

function status(msg){ $("#status").textContent = msg; }

async function init(){
  // Register service worker
  if ('serviceWorker' in navigator){
    try{ await navigator.serviceWorker.register('./sw.js'); }catch(e){ /* ignore */ }
  }
  // Leaflet map
  state.map = L.map('map');
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap contributors'
  }).addTo(state.map);

  try {
    const pos = await getLocation();
    state.userPos = {lat: pos.coords.latitude, lon: pos.coords.longitude};
    state.map.setView([state.userPos.lat, state.userPos.lon], 14);
    L.marker([state.userPos.lat, state.userPos.lon], {title: 'You are here'}).addTo(state.map);
    status('Ready. Tap "Search Nearby" to find fuel stations.');
  } catch (e){
    // Default to Riyadh center if denied/failed
    state.userPos = {lat: 24.7136, lon: 46.6753};
    state.map.setView([state.userPos.lat, state.userPos.lon], 12);
    status('Location permission denied. Using a default location (Riyadh). You can still search.');
  }

  $("#radius").addEventListener('input', e => {
    $("#radiusVal").textContent = (e.target.value/1000).toFixed(1) + " km";
  });
  $("#searchBtn").addEventListener('click', doSearch);
  $("#locateBtn").addEventListener('click', async ()=>{
    status('Locating…');
    try{
      const pos = await getLocation(true);
      state.userPos = {lat: pos.coords.latitude, lon: pos.coords.longitude};
      state.map.setView([state.userPos.lat, state.userPos.lon], 14);
      L.marker([state.userPos.lat, state.userPos.lon], {title: 'You are here'}).addTo(state.map);
      status('Location updated.');
    }catch(e){
      status('Unable to update location.');
    }
  });
}

function getLocation(enableHighAccuracy=false){
  return new Promise((resolve, reject)=>{
    if (!navigator.geolocation) return reject(new Error('Geolocation not supported'));
    navigator.geolocation.getCurrentPosition(resolve, reject, {
      enableHighAccuracy, timeout: 15000, maximumAge: 10000
    });
  });
}

async function doSearch(){
  const R = parseInt($("#radius").value, 10);
  if (!state.userPos) return status('No location yet.');

  const filters = {
    f247: $("#f_247").checked,
    diesel: $("#f_diesel").checked,
    gasoline: $("#f_gasoline").checked,
    o95: $("#f_octane95").checked,
    o91: $("#f_octane91").checked,
    ev: $("#f_electric").checked
  };

  status('Searching nearby stations…');
  const query = `[out:json][timeout:25];
(
  node(around:${R},${state.userPos.lat},${state.userPos.lon})["amenity"="fuel"];
  way(around:${R},${state.userPos.lat},${state.userPos.lon})["amenity"="fuel"];
  relation(around:${R},${state.userPos.lat},${state.userPos.lon})["amenity"="fuel"];
);
out tags center;`;

  let data = null;
  for (const url of OVERPASS){
    try{
      const res = await fetch(url, {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},
        body: new URLSearchParams({ data: query })
      });
      if (!res.ok) throw new Error('HTTP '+res.status);
      data = await res.json();
      break;
    }catch(e){
      // try next endpoint
    }
  }
  if (!data){ status('All Overpass endpoints failed. Try again later.'); return; }

  const elements = data.elements || [];
  const items = elements.map(el=>{
    const lat = el.lat || (el.center && el.center.lat);
    const lon = el.lon || (el.center && el.center.lon);
    if (lat == null || lon == null) return null;
    const dist = haversine(state.userPos, {lat, lon});
    const t = el.tags || {};
    return {
      id: el.id,
      lat, lon, dist,
      name: t.name || 'Gas station',
      brand: t.brand || t.operator || null,
      opening_hours: t.opening_hours || (t['24_7']==='yes' ? '24/7' : (t['opening_hours:signed']?'posted on site':null)),
      is247: t.opening_hours === '24/7' || t['24_7']==='yes',
      diesel: t['fuel:diesel']==='yes',
      gasoline: (t['fuel:gasoline']==='yes') || (t['fuel:octane_95']==='yes') || (t['fuel:octane_91']==='yes'),
      o95: t['fuel:octane_95']==='yes' || t['fuel:95']==='yes',
      o91: t['fuel:octane_91']==='yes' || t['fuel:91']==='yes',
      ev: t['fuel:electricity']==='yes' || t['amenity']==='charging_station',
      operator: t.operator || null,
      website: t.website || t['contact:website'] || null,
      phone: t.phone || t['contact:phone'] || null,
      tags: t
    };
  }).filter(Boolean);

  // Apply filters
  const filtered = items.filter(it=>{
    if (filters.f247 && !it.is247) return false;
    if (filters.diesel && !it.diesel) return false;
    if (filters.gasoline && !it.gasoline) return false;
    if (filters.o95 && !it.o95) return false;
    if (filters.o91 && !it.o91) return false;
    if (filters.ev && !it.ev) return false;
    return true;
  }).sort((a,b)=>a.dist - b.dist);

  state.lastResults = filtered;
  renderResults(filtered);
  drawMarkers(filtered);
  status(`${filtered.length} station(s) within ${km(R)} km.`);
}

function drawMarkers(items){
  if (!state.layer){
    state.layer = L.layerGroup().addTo(state.map);
  }
  state.layer.clearLayers();
  items.forEach((it, idx)=>{
    const m = L.marker([it.lat, it.lon]);
    m.bindPopup(popupHTML(it));
    m.on('click', ()=>highlightList(idx));
    m.addTo(state.layer);
  });
}

function popupHTML(it){
  const lines = [];
  if (it.brand) lines.push(`<div class="row">🏷️ <strong>${escapeHtml(it.brand)}</strong></div>`);
  if (it.opening_hours) lines.push(`<div class="row">⏱️ ${escapeHtml(it.opening_hours)}</div>`);
  const feats = [];
  if (it.diesel) feats.push('Diesel');
  if (it.o95) feats.push('95');
  if (it.o91) feats.push('91');
  if (it.ev) feats.push('EV');
  if (feats.length) lines.push(`<div class="row">⛽ ${feats.join(' • ')}</div>`);
  const dirLink = directionsLink(it.lat, it.lon);
  lines.push(`<div class="row">📍 ${km(it.dist)} km — <a target="_blank" rel="noopener" href="${dirLink}">Directions</a></div>`);
  return `<div class="popup"><h3>${escapeHtml(it.name)}</h3>${lines.join('')}</div>`;
}

function renderResults(items){
  const ul = $("#results");
  ul.innerHTML = "";
  items.slice(0,200).forEach((it, idx)=>{
    const li = document.createElement('li');
    li.className = "result";
    li.innerHTML = `
      <h3>${escapeHtml(it.name)}</h3>
      <div class="row">📍 ${km(it.dist)} km away</div>
      ${it.brand ? `<div class="row">🏷️ ${escapeHtml(it.brand)}</div>` : ""}
      ${it.opening_hours ? `<div class="row">⏱️ ${escapeHtml(it.opening_hours)}</div>` : ""}
      <div class="badges">
        ${it.diesel ? `<span class="badge">Diesel</span>` : ""}
        ${it.o95 ? `<span class="badge">95</span>` : ""}
        ${it.o91 ? `<span class="badge">91</span>` : ""}
        ${it.ev ? `<span class="badge">EV</span>` : ""}
      </div>
      <div class="row">
        <a target="_blank" rel="noopener" href="${directionsLink(it.lat, it.lon)}">Directions</a>
        ${it.website ? `· <a target="_blank" rel="noopener" href="${escapeAttr(it.website)}">Website</a>` : ""}
        ${it.phone ? `· <a href="tel:${escapeAttr(it.phone)}">Call</a>` : ""}
      </div>
    `;
    li.addEventListener('click', ()=>{
      state.map.setView([it.lat, it.lon], 16, {animate:true});
    });
    ul.appendChild(li);
  });
}

function directionsLink(lat, lon){
  const destination = `${lat},${lon}`;
  if (navigator.platform && /iPhone|iPad|iPod/.test(navigator.platform)){
    return `https://maps.apple.com/?daddr=${destination}`;
  }
  return `https://www.google.com/maps/dir/?api=1&destination=${destination}`;
}

function escapeHtml(s){
  return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}
function escapeAttr(s){
  return String(s).replace(/"/g, '&quot;');
}

window.addEventListener('load', init);
